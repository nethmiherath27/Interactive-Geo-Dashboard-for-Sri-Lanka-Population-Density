# sri_lanka_population.py

# Sri Lanka Population Density Dashboard using Bokeh Server


import geopandas as gpd
import pandas as pd
from bokeh.io import curdoc
from bokeh.models import (
    GeoJSONDataSource, LinearColorMapper, ColorBar, HoverTool, WMTSTileSource, Slider, Select
)
from bokeh.plotting import figure
from bokeh.layouts import column, row

# STEP 1: Load district GeoJSON map
geo_path = "geoBoundaries-LKA-ADM2.geojson"
districts = gpd.read_file(geo_path)
print(" GeoJSON districts loaded:", len(districts))
print("GeoJSON columns:", districts.columns.tolist())
print("Example district names:", districts["shapeName"].head().tolist())

# STEP 2: Load Excel dataset
excel_path = "population_density_points.xlsx"
data = pd.read_excel(excel_path)
print("\n Excel data loaded:", len(data))
print("Excel columns:", data.columns.tolist())
print("Example Excel rows:\n", data.head())

# Ensure matching names
if not data["District"].str.contains("District").any():
    data["District"] = data["District"] + " District"

# Merge GeoJSON with Excel data
merged = districts.merge(data, left_on="shapeName", right_on="District", how="left")
print("\n Merged rows:", len(merged))
print("Columns after merge:", merged.columns.tolist())
print(merged[["shapeName", "Density"]].head())

# Check for missing matches
if merged["Population"].isna().all():
    print(" WARNING: All Population values are missing! Check district name matching.")
else:
    print(" Population values merged successfully.")

# Prepare year and region filter controls
years = sorted(data["Year"].unique().tolist())
regions = ["All"] + sorted(data["Region"].unique().tolist())

year_slider = Slider(
    start=min(years),
    end=max(years),
    value=max(years),
    step=1,
    title="Select Year"
)

region_select = Select(
    title="Filter by Region:",
    value="All",
    options=regions
)

# Convert to Web Mercator (for mapping)
merged = merged.to_crs(epsg=3857)

# Prepare GeoJSONDataSource for Bokeh
geo_source = GeoJSONDataSource(geojson=merged.to_json())

# Create color mapper (for choropleth)
mapper = LinearColorMapper(
    palette="Viridis256",
    low=float(merged["Density"].min()),
    high=float(merged["Density"].max())
)

# Create the figure
p = figure(
    title="Sri Lanka Population Density by District",
    x_axis_type="mercator",
    y_axis_type="mercator",
    width=900,
    height=600
)

# Add OSM basemap
tile_source = WMTSTileSource(url="https://a.tile.openstreetmap.org/{Z}/{X}/{Y}.png")
p.add_tile(tile_source)

# Plot polygons
p.patches(
    'xs', 'ys',
    source=geo_source,
    fill_color={'field': 'Density', 'transform': mapper},
    line_color="black",
    line_width=0.5,
    fill_alpha=0.7
)

# Add hover tool
p.add_tools(HoverTool(tooltips=[("District", "@shapeName"), ("Density", "@Population")]))

# Add color bar legend
color_bar = ColorBar(color_mapper=mapper, title="Population (people/km²)", label_standoff=8)
p.add_layout(color_bar, 'right')

# Set initial view to Sri Lanka
p.x_range.start = 8900000
p.x_range.end   = 10000000
p.y_range.start = 760000
p.y_range.end   = 1300000

# Add interactive update logic
def update_geojson():
    """Updates the GeoJSONDataSource based on slider and dropdown selection."""
    selected_year = year_slider.value
    selected_region = region_select.value

    filtered_data = data[data["Year"] == selected_year]
    if selected_region != "All":
        filtered_data = filtered_data[filtered_data["Region"] == selected_region]

    merged_updated = districts.merge(filtered_data, left_on="shapeName", right_on="District", how="left")
    merged_updated = merged_updated.to_crs(epsg=3857)

    if not filtered_data["Density"].isna().all():
        mapper.low = float(filtered_data["Density"].min())
        mapper.high = float(filtered_data["Density"].max())

    geo_source.geojson = merged_updated.to_json()

def update_year(attr, old, new):
    update_geojson()

def update_region(attr, old, new):
    update_geojson()

year_slider.on_change('value', update_year)
region_select.on_change('value', update_region)

# Add to Bokeh document with controls
curdoc().add_root(column(row(region_select, year_slider), p))
curdoc().title = "Sri Lanka Population Density Dashboard"

print("\n Dashboard loaded — open http://localhost:5006/sri_lanka_population in your browser.")
